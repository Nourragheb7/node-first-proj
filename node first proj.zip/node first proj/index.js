//npx nodemon index.js ( to auto update el code)
const express = require("express");//to add  express 
const mongoose = require("mongoose");//to add  database 
const app = express();
const Article = require ("./models/article.js");//toconnect the article file with the index file 

mongoose.connect("mongodb+srv://nourraghebbb:Nour_2002@cluster0.nyiqz.mongodb.net/?retryWrites=true&w=majority&appName=Cluster0")//to connect with database
//mongodb+srv://nourraghebbb:<db_password>@cluster0.nyiqz.mongodb.net/?retryWrites=true&w=majority&appName=Cluster0
.then(()=>{
console.log("connected sucssefuly");
}).catch((error)=>{
  console.log("error with connecting with db",error);
})
app.use(express.json());
app.get("/hello", (req, res) => {

});

app.get("/numbers", (req,res) =>{
  let numbers = "";
  for(let i=0 ;i<=100;i++){
    numbers += i +" - ";
  }
  //res.send(`the numbers are :${numbers}`);
  res.render("numbers.ejs",{
    name:"nour",
    numbers:numbers,
  });
});
app.get("/findsum/:number1/:number2", (req,res) =>{
  const num1=req.params.number1 
  const num2=req.params.number2
  const total=Number(num1)+Number(num2)
  console.log(req.params);
  
  res.send(`the total is: ${total}`);
});
app.get("/sayhello", (req,res) =>{
  //console.log(req.body);
  //console.log(req.query);
  //res.send(`hello ${req.body.name},age is:${req.query.age}`);
  res.json({
    name:req.body.name,
    age:req.query.age,
    language:"arabic",
  })
});

app.get("/hey", (req,res) =>{
  res.render("numbers.ejs");  

});
app.post("/addcomment", (req,res) =>{
  res.send("post request on add comment");

});
app.delete("/testingdelete", (req,res) =>{
  res.send("deleted");

});


//atricles endpoints
app.post("/articles", async (req, res) => {
  const newarticle = new Article();  // Initialize the new article object
  const arttitle = req.body.articletitle;
  const artbody = req.body.articlebody;

  // Use the values from the request body
  newarticle.title = arttitle;  // Assign title
  newarticle.body = artbody;  // Assign body
  newarticle.numberOFLikes = 100;  // Assign number of likes
  
  // Save the new article to the database
  await newarticle.save();

  // Send response with the new article as JSON
  res.json(newarticle);  // This will return the newly created article as JSON
});

app.get("/articles", async (req,res)=>{
  const articles= await Article.find()
  console.log("the articles are",articles);
  res.json(articles);
});
app.get("/articles/:articleId", async (req, res) => {
  const id = req.params.articleId;
  try {
    const article = await Article.findById(id);
    res.json(article);
    return;
  } catch (error) {
    console.log("Error while reading article of id:", id);
    return res.send("Error");
  }
});
app.delete("/articles/:articleId", async (req, res) => {
  const id = req.params.articleId;
  try {
    const article = await Article.findByIdAndDelete(id);
    res.json(article);
    return;
  } catch (error) {
    console.log("Error while reading article of id:", id);
    return res.send("Error");
  }
});
app.get("/showarticles",async(req,res)=>{
  const articles = await Article.find();
  res.render("articles.ejs", {
    allArticles: articles,
  });
  
});
app.listen(3000,()=>{
  console.log("i am listening in port 3000");
});
app.get("/hi", (req,res) =>{
  res.send("you vistsied hi ");

});